import math

z = int(input("Введите число"))
if z <= 0:
    x = math.pow(z,2)+5
else:
   x = 1 / math.sqrt(z - 1)

y = math.pow(math.sin(math.pow(x,2)-1),3)
y = y + math.log(math.fabs(x))
y = y + math.pow(math.e, x)
print(y)