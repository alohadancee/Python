while True:
    a = int(input('Введите число 1 = '))
    b = int(input('Введите число 2 = '))
    c = input('Введите операцию (+,-,*,/) = ')
    if c == '+':
        print(a+b)
    elif c == '-':
        print(a-b)
    elif c == '*':
        print(a*b)
    elif c == '/' and b != 0:
        print(a/b)
    elif b == 0:
        print('на ноль делить нельзя')
    elif c == '0':
        print('Программа завершена')
        break
    else:
        print('что ты написал не так, да уж...')

